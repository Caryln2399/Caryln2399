<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_HospitalReadmission</name>
   <tag></tag>
   <elementGuidId>2b1c78d6-27b9-4a6f-8202-a078a5906760</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>hospital_readmission</value>
   </webElementProperties>
</WebElementEntity>
