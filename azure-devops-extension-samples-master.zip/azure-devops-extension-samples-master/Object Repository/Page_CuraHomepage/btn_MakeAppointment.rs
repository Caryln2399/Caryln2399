<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_MakeAppointment</name>
   <tag></tag>
   <elementGuidId>36ab10ef-42ea-4957-9e53-f8e9886ae996</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>btn-make-appointment</value>
   </webElementProperties>
</WebElementEntity>
