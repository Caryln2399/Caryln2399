<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>txt_UserName</name>
   <tag></tag>
   <elementGuidId>e964d4cf-97b4-45cb-a405-f5d3df04fe38</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>txt-username</value>
   </webElementProperties>
</WebElementEntity>
